echo |< echo segf

echo segf >| echo is this invalid

echo >          >           < "echo"

echo >          >         | echo kekw

echo >          >         | echo super valid

echo <          <         > echo

echo <  < <         > ok

echo <  < | echo ok

echo <  < |    < ok

echo <      < |    > echo

echo >>| echo super valid

echo >>< "echo"

echo < < < echo seegf

echo > > < "echo"

echo > > | echo kekw

echo > > | echo super valid

echo < < > echo

echo < < < > ok

echo >>| echo kekw

echo | < echo segf

echo <<| echo ok

echo <<|< ok

echo <<|> echo

echo <<> echo

echo <<<> ok

echo segfault <"<<<"<<amazing
.
amazing

echo seg < > echo seg

echo seg > < echo segf

echo seg < < > echo segf

echo seg < < < > echo segf

echo segf > | echo is this invalid

echo segf < | < echo super valid

echo < < | echo ok

echo < < | < ok

echo < < | > echo

echo segfault < " < < < " < < amazing
.
amazing

echo seg <  > echo seg

echo seg >  < echo segf

echo seg <      < > echo segf

echo seg <      < <    > echo segf

echo <      <     < echo seegf

echo |      < echo segf

echo segf >     | echo is this invalid

echo segf <         |        < echo super valid


echo segfault <"    <   <   <"  <   <   amazing
.
amazing

echo seg <> echo seg

echo seg >< echo segf

echo seg <<> echo segf

echo seg <<<> echo segf

echo <<< echo seegf

echo segf <|< echo super valid
