/bin/echo $HALLO42
env | grep HALLO42
export HALLO42=42
/bin/echo $HALLO42
env | grep HALLO42
