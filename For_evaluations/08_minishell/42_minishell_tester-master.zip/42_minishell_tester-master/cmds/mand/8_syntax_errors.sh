# **************************************************************************** #
#                                SYNTAX ERRORS                                 #
# **************************************************************************** #

>

<

<<

> > > > >

>> >> >> >>

>>>>>>>>>

<<<<<<<<<

~

< < < < < <

/bin/cat ><

/bin/cat <Makefile >

cat 42 42

echo >

echo > <

.

..

echo | |

EechoE

.echo.

>echo>
/bin/rm -f echo

<echo<
/bin/rm -f echo

>>echo>>
/bin/rm -f echo

|echo|

trying to destroy your minishell

|

| test

| | |

| | | | test

| test

echo > <

hello world
||||||||
            
cat wouaf wouaf
>

> > > >

>> >> >> >>

<<

/

\\\

rm -f something

| echo -n oui

trying to destroy your minishell
trying something again echo if you see this message thats not a good new
qewew
wtf
hi im zsolt
nice to meet you if these tests are green
your minishell is perfect

<<| echo wtf

>>| echo wtf

>| echo wtf
/bin/rm -rf echo

<| echo wtf

echo "<<| echo wtf"

echo ">>| echo wtf"

echo ">| echo wtf"

echo "<| echo wtf"

<>

< >